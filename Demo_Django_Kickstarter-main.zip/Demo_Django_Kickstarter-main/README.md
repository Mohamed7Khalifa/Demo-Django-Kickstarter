# Demo-Django-Kickstarter
Demo version of kickstarter website using django framework
## Run project locally
```python
    python3 manage.py runserver [port]
```
if you didn't set the port by default it is 8000
